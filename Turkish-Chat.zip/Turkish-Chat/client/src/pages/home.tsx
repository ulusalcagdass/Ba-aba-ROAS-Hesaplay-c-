import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Calculation, ProductInput } from "@shared/schema";
import { 
  Calculator, 
  TrendingUp, 
  Target, 
  Percent, 
  DollarSign, 
  CreditCard, 
  Package,
  Plus,
  X,
  BarChart3,
  Copy,
  Save,
  History,
  Trash2,
  FolderOpen,
  Loader2
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

interface InputValues {
  id: string;
  productName: string;
  aov: number;
  productCost: number;
  creditCardFeePercent: number;
  paymentProcessingFee: number;
  shippingCost: number;
  fulfillmentCost: number;
  marginalAov: number;
}

interface CalculatedValues {
  creditCardFee: number;
  totalProductCostPlusFulfillment: number;
  costPercentage: number;
  grossMarginPercent: number;
  expectedGrossProfit: number;
  marginalProfit: number;
  breakEvenRoas: number;
  targetRoas10: number;
  targetRoas15: number;
  targetRoas20: number;
}

const createDefaultValues = (id: string, name: string = "Ürün Adı"): InputValues => ({
  id,
  productName: name,
  aov: 3750,
  productCost: 1250,
  creditCardFeePercent: 8.99,
  paymentProcessingFee: 0.25,
  shippingCost: 60,
  fulfillmentCost: 175,
  marginalAov: 3900,
});

function formatCurrency(value: number): string {
  return new Intl.NumberFormat("tr-TR", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value) + "₺";
}

function formatPercent(value: number): string {
  return "%" + new Intl.NumberFormat("tr-TR", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value);
}

function formatRoas(value: number): string {
  return new Intl.NumberFormat("tr-TR", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value);
}

function calculateValues(values: InputValues): CalculatedValues {
  const creditCardFee = (values.aov * values.creditCardFeePercent) / 100;
  const totalProductCostPlusFulfillment =
    values.productCost +
    creditCardFee +
    values.paymentProcessingFee +
    values.shippingCost +
    values.fulfillmentCost;
  const costPercentage = values.aov > 0 ? (totalProductCostPlusFulfillment / values.aov) * 100 : 0;
  const grossMarginPercent = 100 - costPercentage;
  const expectedGrossProfit = values.aov - totalProductCostPlusFulfillment;

  const marginalProfit = values.marginalAov - totalProductCostPlusFulfillment;
  const breakEvenRoas = marginalProfit > 0 ? values.marginalAov / marginalProfit : 0;
  const targetRoas10 = (marginalProfit - values.marginalAov * 0.10) > 0 
    ? values.marginalAov / (marginalProfit - values.marginalAov * 0.10) : 0;
  const targetRoas15 = (marginalProfit - values.marginalAov * 0.15) > 0 
    ? values.marginalAov / (marginalProfit - values.marginalAov * 0.15) : 0;
  const targetRoas20 = (marginalProfit - values.marginalAov * 0.20) > 0 
    ? values.marginalAov / (marginalProfit - values.marginalAov * 0.20) : 0;

  return {
    creditCardFee,
    totalProductCostPlusFulfillment,
    costPercentage,
    grossMarginPercent,
    expectedGrossProfit,
    marginalProfit,
    breakEvenRoas: isFinite(breakEvenRoas) && breakEvenRoas > 0 ? breakEvenRoas : 0,
    targetRoas10: isFinite(targetRoas10) && targetRoas10 > 0 ? targetRoas10 : 0,
    targetRoas15: isFinite(targetRoas15) && targetRoas15 > 0 ? targetRoas15 : 0,
    targetRoas20: isFinite(targetRoas20) && targetRoas20 > 0 ? targetRoas20 : 0,
  };
}

function generateId(): string {
  return Math.random().toString(36).substring(2, 9);
}

interface ProductCardProps {
  product: InputValues;
  calculations: CalculatedValues;
  onUpdate: (field: keyof InputValues, value: string) => void;
  onRemove: () => void;
  onDuplicate: () => void;
  canRemove: boolean;
  index: number;
}

function ProductCard({ product, calculations, onUpdate, onRemove, onDuplicate, canRemove, index }: ProductCardProps) {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div className="flex-1 min-w-[200px]">
          <Input
            data-testid={`input-product-name-${index}`}
            type="text"
            value={product.productName}
            onChange={(e) => onUpdate("productName", e.target.value)}
            className="text-lg font-semibold border-0 border-b rounded-none px-0 focus-visible:ring-0"
            placeholder="Ürün adı girin..."
          />
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={onDuplicate}
            data-testid={`button-duplicate-${index}`}
          >
            <Copy className="w-4 h-4 mr-1" />
            Kopyala
          </Button>
          {canRemove && (
            <Button
              variant="ghost"
              size="icon"
              onClick={onRemove}
              className="text-destructive"
              data-testid={`button-remove-${index}`}
            >
              <X className="w-4 h-4" />
            </Button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center gap-2 text-xl">
              <Package className="w-5 h-5 text-primary" />
              Ürün Bilgileri
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor={`aov-${product.id}`} className="text-sm font-medium">
                Ortalama Sipariş Değeri (AOV)
              </Label>
              <div className="relative">
                <Input
                  id={`aov-${product.id}`}
                  data-testid={`input-aov-${index}`}
                  type="number"
                  step="0.01"
                  value={product.aov}
                  onChange={(e) => onUpdate("aov", e.target.value)}
                  className="text-right pr-8"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">₺</span>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor={`productCost-${product.id}`} className="text-sm font-medium">
                Ürün Maliyeti (Tekil)
              </Label>
              <div className="relative">
                <Input
                  id={`productCost-${product.id}`}
                  data-testid={`input-product-cost-${index}`}
                  type="number"
                  step="0.01"
                  value={product.productCost}
                  onChange={(e) => onUpdate("productCost", e.target.value)}
                  className="text-right pr-8"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">₺</span>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor={`marginalAov-${product.id}`} className="text-sm font-medium">
                Marjinal AOV
              </Label>
              <div className="relative">
                <Input
                  id={`marginalAov-${product.id}`}
                  data-testid={`input-marginal-aov-${index}`}
                  type="number"
                  step="0.01"
                  value={product.marginalAov}
                  onChange={(e) => onUpdate("marginalAov", e.target.value)}
                  className="text-right pr-8"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">₺</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center gap-2 text-xl">
              <CreditCard className="w-5 h-5 text-primary" />
              Sabit Ücretler
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor={`creditCardFeePercent-${product.id}`} className="text-sm font-medium">
                Kredi Kartı Ücretleri
              </Label>
              <div className="relative">
                <Input
                  id={`creditCardFeePercent-${product.id}`}
                  data-testid={`input-credit-card-fee-${index}`}
                  type="number"
                  step="0.01"
                  value={product.creditCardFeePercent}
                  onChange={(e) => onUpdate("creditCardFeePercent", e.target.value)}
                  className="text-right pr-8"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">%</span>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor={`paymentProcessingFee-${product.id}`} className="text-sm font-medium">
                Ödeme İşlem Ücreti
              </Label>
              <div className="relative">
                <Input
                  id={`paymentProcessingFee-${product.id}`}
                  data-testid={`input-payment-fee-${index}`}
                  type="number"
                  step="0.01"
                  value={product.paymentProcessingFee}
                  onChange={(e) => onUpdate("paymentProcessingFee", e.target.value)}
                  className="text-right pr-8"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">₺</span>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor={`shippingCost-${product.id}`} className="text-sm font-medium">
                Kargo Ücreti
              </Label>
              <div className="relative">
                <Input
                  id={`shippingCost-${product.id}`}
                  data-testid={`input-shipping-cost-${index}`}
                  type="number"
                  step="0.01"
                  value={product.shippingCost}
                  onChange={(e) => onUpdate("shippingCost", e.target.value)}
                  className="text-right pr-8"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">₺</span>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor={`fulfillmentCost-${product.id}`} className="text-sm font-medium">
                Operasyon (Fulfillment) Maliyeti
              </Label>
              <div className="relative">
                <Input
                  id={`fulfillmentCost-${product.id}`}
                  data-testid={`input-fulfillment-cost-${index}`}
                  type="number"
                  step="0.01"
                  value={product.fulfillmentCost}
                  onChange={(e) => onUpdate("fulfillmentCost", e.target.value)}
                  className="text-right pr-8"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">₺</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-muted/30">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2 text-xl">
            <DollarSign className="w-5 h-5 text-primary" />
            Hesaplanan Değerler
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="p-4 bg-card rounded-lg border border-card-border">
              <p className="text-sm text-muted-foreground mb-1">Kredi Kartı Ücreti</p>
              <p className="text-lg font-semibold" data-testid={`text-credit-card-fee-${index}`}>
                {formatCurrency(calculations.creditCardFee)}
              </p>
            </div>
            <div className="p-4 bg-card rounded-lg border border-card-border">
              <p className="text-sm text-muted-foreground mb-1">Toplam Maliyet</p>
              <p className="text-lg font-semibold" data-testid={`text-total-cost-${index}`}>
                {formatCurrency(calculations.totalProductCostPlusFulfillment)}
              </p>
            </div>
            <div className="p-4 bg-card rounded-lg border border-card-border">
              <p className="text-sm text-muted-foreground mb-1">Maliyet Yüzdesi</p>
              <p className="text-lg font-semibold" data-testid={`text-cost-percentage-${index}`}>
                {formatPercent(calculations.costPercentage)}
              </p>
            </div>
            <div className="p-4 bg-card rounded-lg border border-card-border">
              <p className="text-sm text-muted-foreground mb-1">Brüt Kar Marjı</p>
              <p className="text-lg font-semibold text-green-600 dark:text-green-400" data-testid={`text-gross-margin-${index}`}>
                {formatPercent(calculations.grossMarginPercent)}
              </p>
            </div>
          </div>
          <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-primary/5 rounded-lg border border-primary/20">
              <p className="text-sm text-muted-foreground mb-1">Sipariş Başına Kar</p>
              <p className="text-2xl font-bold text-primary" data-testid={`text-profit-per-order-${index}`}>
                {formatCurrency(calculations.marginalProfit)}
              </p>
            </div>
            <div className="p-4 bg-primary/5 rounded-lg border border-primary/20">
              <p className="text-sm text-muted-foreground mb-1">Beklenen Brüt Kar</p>
              <p className="text-2xl font-bold text-primary" data-testid={`text-expected-profit-${index}`}>
                {formatCurrency(calculations.expectedGrossProfit)}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <Card className="border-2 border-primary/50 bg-primary/5">
          <CardContent className="pt-6 text-center">
            <div className="flex justify-center mb-3">
              <div className="p-2 bg-primary/20 rounded-full">
                <Target className="w-5 h-5 text-primary" />
              </div>
            </div>
            <p className="text-2xl font-bold text-primary mb-1" data-testid={`text-break-even-roas-${index}`}>
              {formatRoas(calculations.breakEvenRoas)}
            </p>
            <p className="text-xs text-muted-foreground font-medium">Başabaş ROAS</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6 text-center">
            <div className="flex justify-center mb-3">
              <div className="p-2 bg-green-500/20 rounded-full">
                <TrendingUp className="w-5 h-5 text-green-600 dark:text-green-400" />
              </div>
            </div>
            <p className="text-2xl font-bold text-green-600 dark:text-green-400 mb-1" data-testid={`text-roas-10-${index}`}>
              {formatRoas(calculations.targetRoas10)}
            </p>
            <p className="text-xs text-muted-foreground font-medium">%10 Marj ROAS</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6 text-center">
            <div className="flex justify-center mb-3">
              <div className="p-2 bg-blue-500/20 rounded-full">
                <TrendingUp className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              </div>
            </div>
            <p className="text-2xl font-bold text-blue-600 dark:text-blue-400 mb-1" data-testid={`text-roas-15-${index}`}>
              {formatRoas(calculations.targetRoas15)}
            </p>
            <p className="text-xs text-muted-foreground font-medium">%15 Marj ROAS</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6 text-center">
            <div className="flex justify-center mb-3">
              <div className="p-2 bg-purple-500/20 rounded-full">
                <Percent className="w-5 h-5 text-purple-600 dark:text-purple-400" />
              </div>
            </div>
            <p className="text-2xl font-bold text-purple-600 dark:text-purple-400 mb-1" data-testid={`text-roas-20-${index}`}>
              {formatRoas(calculations.targetRoas20)}
            </p>
            <p className="text-xs text-muted-foreground font-medium">%20 Marj ROAS</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

interface ComparisonTableProps {
  products: InputValues[];
  allCalculations: Map<string, CalculatedValues>;
}

function ComparisonTable({ products, allCalculations }: ComparisonTableProps) {
  if (products.length < 2) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        <BarChart3 className="w-12 h-12 mx-auto mb-3 opacity-50" />
        <p>Karşılaştırma için en az 2 ürün ekleyin</p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr className="border-b">
            <th className="text-left p-3 font-medium text-muted-foreground">Metrik</th>
            {products.map((product, index) => (
              <th key={product.id} className="text-right p-3 font-semibold" data-testid={`comparison-header-${index}`}>
                {product.productName}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          <tr className="border-b">
            <td className="p-3 text-muted-foreground">AOV</td>
            {products.map((product, index) => (
              <td key={product.id} className="text-right p-3 font-medium" data-testid={`comparison-aov-${index}`}>
                {formatCurrency(product.aov)}
              </td>
            ))}
          </tr>
          <tr className="border-b">
            <td className="p-3 text-muted-foreground">Toplam Maliyet</td>
            {products.map((product, index) => {
              const calc = allCalculations.get(product.id);
              return (
                <td key={product.id} className="text-right p-3 font-medium" data-testid={`comparison-total-cost-${index}`}>
                  {calc ? formatCurrency(calc.totalProductCostPlusFulfillment) : "-"}
                </td>
              );
            })}
          </tr>
          <tr className="border-b">
            <td className="p-3 text-muted-foreground">Brüt Kar Marjı</td>
            {products.map((product, index) => {
              const calc = allCalculations.get(product.id);
              return (
                <td key={product.id} className="text-right p-3 font-medium text-green-600 dark:text-green-400" data-testid={`comparison-margin-${index}`}>
                  {calc ? formatPercent(calc.grossMarginPercent) : "-"}
                </td>
              );
            })}
          </tr>
          <tr className="border-b">
            <td className="p-3 text-muted-foreground">Sipariş Başına Kar</td>
            {products.map((product, index) => {
              const calc = allCalculations.get(product.id);
              return (
                <td key={product.id} className="text-right p-3 font-medium" data-testid={`comparison-profit-${index}`}>
                  {calc ? formatCurrency(calc.marginalProfit) : "-"}
                </td>
              );
            })}
          </tr>
          <tr className="border-b bg-primary/5">
            <td className="p-3 font-medium">Başabaş ROAS</td>
            {products.map((product, index) => {
              const calc = allCalculations.get(product.id);
              return (
                <td key={product.id} className="text-right p-3 font-bold text-primary" data-testid={`comparison-break-even-${index}`}>
                  {calc ? formatRoas(calc.breakEvenRoas) : "-"}
                </td>
              );
            })}
          </tr>
          <tr className="border-b">
            <td className="p-3 text-muted-foreground">%10 Marj ROAS</td>
            {products.map((product, index) => {
              const calc = allCalculations.get(product.id);
              return (
                <td key={product.id} className="text-right p-3 font-medium text-green-600 dark:text-green-400" data-testid={`comparison-roas10-${index}`}>
                  {calc ? formatRoas(calc.targetRoas10) : "-"}
                </td>
              );
            })}
          </tr>
          <tr className="border-b">
            <td className="p-3 text-muted-foreground">%15 Marj ROAS</td>
            {products.map((product, index) => {
              const calc = allCalculations.get(product.id);
              return (
                <td key={product.id} className="text-right p-3 font-medium text-blue-600 dark:text-blue-400" data-testid={`comparison-roas15-${index}`}>
                  {calc ? formatRoas(calc.targetRoas15) : "-"}
                </td>
              );
            })}
          </tr>
          <tr>
            <td className="p-3 text-muted-foreground">%20 Marj ROAS</td>
            {products.map((product, index) => {
              const calc = allCalculations.get(product.id);
              return (
                <td key={product.id} className="text-right p-3 font-medium text-purple-600 dark:text-purple-400" data-testid={`comparison-roas20-${index}`}>
                  {calc ? formatRoas(calc.targetRoas20) : "-"}
                </td>
              );
            })}
          </tr>
        </tbody>
      </table>
    </div>
  );
}

interface RoasChartProps {
  products: InputValues[];
  allCalculations: Map<string, CalculatedValues>;
}

function RoasChart({ products, allCalculations }: RoasChartProps) {
  if (products.length < 2) {
    return null;
  }

  const chartData = products.map((product) => {
    const calc = allCalculations.get(product.id);
    return {
      name: product.productName.length > 12 
        ? product.productName.substring(0, 12) + "..." 
        : product.productName,
      "Başabaş": calc?.breakEvenRoas || 0,
      "%10 Marj": calc?.targetRoas10 || 0,
      "%15 Marj": calc?.targetRoas15 || 0,
      "%20 Marj": calc?.targetRoas20 || 0,
    };
  });

  const marginChartData = products.map((product) => {
    const calc = allCalculations.get(product.id);
    return {
      name: product.productName.length > 12 
        ? product.productName.substring(0, 12) + "..." 
        : product.productName,
      "Kar Marjı (%)": calc?.grossMarginPercent || 0,
      "Maliyet (%)": calc?.costPercentage || 0,
    };
  });

  return (
    <div className="space-y-8 mt-8">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Target className="w-5 h-5 text-primary" />
            ROAS Hedefleri Karşılaştırması
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]" data-testid="chart-roas-comparison">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip 
                  formatter={(value: number) => formatRoas(value)}
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '6px'
                  }}
                />
                <Legend />
                <Bar dataKey="Başabaş" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                <Bar dataKey="%10 Marj" fill="#22c55e" radius={[4, 4, 0, 0]} />
                <Bar dataKey="%15 Marj" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                <Bar dataKey="%20 Marj" fill="#a855f7" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <TrendingUp className="w-5 h-5 text-primary" />
            Kar Marjı vs Maliyet
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]" data-testid="chart-margin-comparison">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={marginChartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} unit="%" />
                <Tooltip 
                  formatter={(value: number) => formatPercent(value)}
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '6px'
                  }}
                />
                <Legend />
                <Bar dataKey="Kar Marjı (%)" fill="#22c55e" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Maliyet (%)" fill="#ef4444" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default function Home() {
  const [products, setProducts] = useState<InputValues[]>([
    createDefaultValues(generateId(), "Ürün 1"),
  ]);
  const [activeTab, setActiveTab] = useState<string>("product-0");
  const [saveDialogOpen, setSaveDialogOpen] = useState(false);
  const [historyDialogOpen, setHistoryDialogOpen] = useState(false);
  const [calculationName, setCalculationName] = useState("");
  const { toast } = useToast();

  const { data: savedCalculations = [], isLoading: isLoadingCalculations } = useQuery<Calculation[]>({
    queryKey: ['/api/calculations'],
  });

  const saveCalculationMutation = useMutation({
    mutationFn: async (data: { name: string; products: ProductInput[] }) => {
      return apiRequest('/api/calculations', {
        method: 'POST',
        body: JSON.stringify(data),
        headers: { 'Content-Type': 'application/json' },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/calculations'] });
      setSaveDialogOpen(false);
      setCalculationName("");
      toast({
        title: "Hesaplama kaydedildi",
        description: "Hesaplamanız başarıyla kaydedildi.",
      });
    },
    onError: () => {
      toast({
        title: "Hata",
        description: "Hesaplama kaydedilirken bir hata oluştu.",
        variant: "destructive",
      });
    },
  });

  const deleteCalculationMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest(`/api/calculations/${id}`, {
        method: 'DELETE',
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/calculations'] });
      toast({
        title: "Hesaplama silindi",
        description: "Hesaplama başarıyla silindi.",
      });
    },
    onError: () => {
      toast({
        title: "Hata",
        description: "Hesaplama silinirken bir hata oluştu.",
        variant: "destructive",
      });
    },
  });

  const allCalculations = useMemo(() => {
    const calcMap = new Map<string, CalculatedValues>();
    products.forEach((product) => {
      calcMap.set(product.id, calculateValues(product));
    });
    return calcMap;
  }, [products]);

  const handleSaveCalculation = () => {
    if (!calculationName.trim()) {
      toast({
        title: "Hata",
        description: "Lütfen hesaplama için bir isim girin.",
        variant: "destructive",
      });
      return;
    }
    const productsToSave: ProductInput[] = products.map(({ id, ...rest }) => rest);
    saveCalculationMutation.mutate({ name: calculationName.trim(), products: productsToSave });
  };

  const handleLoadCalculation = (calculation: Calculation) => {
    const loadedProducts: InputValues[] = calculation.products.map((p) => ({
      id: generateId(),
      ...p,
    }));
    setProducts(loadedProducts);
    setActiveTab("product-0");
    setHistoryDialogOpen(false);
    toast({
      title: "Hesaplama yüklendi",
      description: `"${calculation.name}" hesaplaması yüklendi.`,
    });
  };

  const handleDeleteCalculation = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    deleteCalculationMutation.mutate(id);
  };

  const handleProductUpdate = (productId: string, field: keyof InputValues, value: string) => {
    setProducts((prev) =>
      prev.map((p) => {
        if (p.id !== productId) return p;
        if (field === "productName" || field === "id") {
          return { ...p, [field]: value };
        }
        return { ...p, [field]: parseFloat(value) || 0 };
      })
    );
  };

  const addProduct = () => {
    const newId = generateId();
    const newProduct = createDefaultValues(newId, `Ürün ${products.length + 1}`);
    setProducts((prev) => [...prev, newProduct]);
    setActiveTab(`product-${products.length}`);
  };

  const removeProduct = (productId: string) => {
    const index = products.findIndex((p) => p.id === productId);
    setProducts((prev) => prev.filter((p) => p.id !== productId));
    if (activeTab === `product-${index}`) {
      setActiveTab("product-0");
    }
  };

  const duplicateProduct = (productId: string) => {
    const product = products.find((p) => p.id === productId);
    if (!product) return;
    const newId = generateId();
    const newProduct = {
      ...product,
      id: newId,
      productName: `${product.productName} (Kopya)`,
    };
    setProducts((prev) => [...prev, newProduct]);
    setActiveTab(`product-${products.length}`);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto px-4 md:px-8 py-8 md:py-12">
        <header className="text-center mb-10">
          <div className="flex items-center justify-center gap-3 mb-3">
            <div className="p-3 bg-primary/10 rounded-lg">
              <Calculator className="w-8 h-8 text-primary" />
            </div>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-2">
            Başabaş ROAS Hesaplayıcı
          </h1>
          <p className="text-muted-foreground text-base md:text-lg max-w-2xl mx-auto mb-6">
            Birden fazla ürün için maliyet ve ROAS hesaplamalarını yapın, karşılaştırın.
          </p>
          <div className="flex items-center justify-center gap-3 flex-wrap">
            <Dialog open={saveDialogOpen} onOpenChange={setSaveDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" data-testid="button-save-calculation">
                  <Save className="w-4 h-4 mr-2" />
                  Kaydet
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Hesaplamayı Kaydet</DialogTitle>
                  <DialogDescription>
                    Mevcut hesaplamanızı daha sonra kullanmak üzere kaydedin.
                  </DialogDescription>
                </DialogHeader>
                <div className="py-4">
                  <Label htmlFor="calculation-name">Hesaplama Adı</Label>
                  <Input
                    id="calculation-name"
                    data-testid="input-calculation-name"
                    value={calculationName}
                    onChange={(e) => setCalculationName(e.target.value)}
                    placeholder="Örn: Ocak 2024 Ürün Analizi"
                    className="mt-2"
                  />
                </div>
                <DialogFooter>
                  <Button
                    variant="outline"
                    onClick={() => setSaveDialogOpen(false)}
                    data-testid="button-cancel-save"
                  >
                    İptal
                  </Button>
                  <Button
                    onClick={handleSaveCalculation}
                    disabled={saveCalculationMutation.isPending}
                    data-testid="button-confirm-save"
                  >
                    {saveCalculationMutation.isPending ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Save className="w-4 h-4 mr-2" />
                    )}
                    Kaydet
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>

            <Dialog open={historyDialogOpen} onOpenChange={setHistoryDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" data-testid="button-history">
                  <History className="w-4 h-4 mr-2" />
                  Geçmiş
                  {savedCalculations.length > 0 && (
                    <span className="ml-2 bg-primary text-primary-foreground text-xs px-2 py-0.5 rounded-full">
                      {savedCalculations.length}
                    </span>
                  )}
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-lg">
                <DialogHeader>
                  <DialogTitle>Kaydedilmiş Hesaplamalar</DialogTitle>
                  <DialogDescription>
                    Daha önce kaydettiğiniz hesaplamaları yükleyin veya silin.
                  </DialogDescription>
                </DialogHeader>
                <div className="py-4">
                  {isLoadingCalculations ? (
                    <div className="flex items-center justify-center py-8">
                      <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
                    </div>
                  ) : savedCalculations.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <FolderOpen className="w-12 h-12 mx-auto mb-3 opacity-50" />
                      <p>Henüz kaydedilmiş hesaplama yok.</p>
                      <p className="text-sm mt-1">Hesaplamalarınızı kaydetmek için "Kaydet" butonunu kullanın.</p>
                    </div>
                  ) : (
                    <ScrollArea className="h-[300px] pr-4">
                      <div className="space-y-2">
                        {savedCalculations.map((calc) => (
                          <div
                            key={calc.id}
                            onClick={() => handleLoadCalculation(calc)}
                            className="flex items-center justify-between p-3 rounded-lg border border-border hover-elevate cursor-pointer"
                            data-testid={`calculation-item-${calc.id}`}
                          >
                            <div className="flex-1 min-w-0">
                              <p className="font-medium truncate">{calc.name}</p>
                              <p className="text-sm text-muted-foreground">
                                {calc.products.length} ürün
                                {calc.createdAt && (
                                  <span className="ml-2">
                                    {new Date(calc.createdAt).toLocaleDateString('tr-TR')}
                                  </span>
                                )}
                              </p>
                            </div>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={(e) => handleDeleteCalculation(calc.id, e)}
                              className="text-destructive ml-2 flex-shrink-0"
                              disabled={deleteCalculationMutation.isPending}
                              data-testid={`button-delete-calculation-${calc.id}`}
                            >
                              {deleteCalculationMutation.isPending ? (
                                <Loader2 className="w-4 h-4 animate-spin" />
                              ) : (
                                <Trash2 className="w-4 h-4" />
                              )}
                            </Button>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  )}
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </header>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <div className="flex items-center gap-2 flex-wrap">
            <TabsList className="flex-wrap h-auto gap-1">
              {products.map((product, index) => (
                <TabsTrigger
                  key={product.id}
                  value={`product-${index}`}
                  className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                  data-testid={`tab-product-${index}`}
                >
                  {product.productName.length > 15
                    ? product.productName.substring(0, 15) + "..."
                    : product.productName}
                </TabsTrigger>
              ))}
              <TabsTrigger
                value="comparison"
                className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                data-testid="tab-comparison"
              >
                <BarChart3 className="w-4 h-4 mr-1" />
                Karşılaştır
              </TabsTrigger>
            </TabsList>
            <Button
              variant="outline"
              size="sm"
              onClick={addProduct}
              data-testid="button-add-product"
            >
              <Plus className="w-4 h-4 mr-1" />
              Yeni Ürün
            </Button>
          </div>

          {products.map((product, index) => (
            <TabsContent key={product.id} value={`product-${index}`} className="space-y-6">
              <ProductCard
                product={product}
                calculations={allCalculations.get(product.id)!}
                onUpdate={(field, value) => handleProductUpdate(product.id, field, value)}
                onRemove={() => removeProduct(product.id)}
                onDuplicate={() => duplicateProduct(product.id)}
                canRemove={products.length > 1}
                index={index}
              />
            </TabsContent>
          ))}

          <TabsContent value="comparison">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5 text-primary" />
                  Ürün Karşılaştırması
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ComparisonTable products={products} allCalculations={allCalculations} />
              </CardContent>
            </Card>
            <RoasChart products={products} allCalculations={allCalculations} />
          </TabsContent>
        </Tabs>

        <footer className="text-center pt-8 pb-4 border-t border-border mt-8">
          <p className="text-sm text-muted-foreground">
            Performans Pazarlama için Başabaş ROAS Hesaplayıcı
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            basabasroas.com
          </p>
        </footer>
      </div>
    </div>
  );
}
